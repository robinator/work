% A driver for canny.m...
image_in1 = imread('edge-images/elephants.pgm');
image_in2 = imread('edge-images/bear.pgm');
image_in3 = imread('edge-images/boat.pgm');
image_in4 = imread('edge-images/tsukuba.pgm');

img_out1 = canny(image_in1, 100, 250, 1);
img_out2 = canny(image_in2, 100, 250, 1);
img_out3 = canny(image_in3, 100, 250, 1);
img_out4 = canny(image_in4, 100, 250, 1);

imwrite(img_out1, 'edge_elephants.pbm');
imwrite(img_out2, 'edge_bear.pbm');
imwrite(img_out3, 'edge_boat.pbm');
imwrite(img_out4, 'edge_tsukuba.pbm');
